
/**
 * A rectangle-shaped Shape
 * Dartmouth CS 10, Winter 2015
 */
public class Rectangle extends Shape {
	// TODO: YOUR CODE HERE
}
