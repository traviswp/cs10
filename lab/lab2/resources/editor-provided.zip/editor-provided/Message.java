
/**
 * Representation of a message for updating a sketch
 * Dartmouth CS 10, Winter 2015
 */
public class Message {
	// Instance variables
	// TODO: YOUR CODE HERE
	
	/**
	 * Initializes it from a string representation used for communication
	 * @param msg
	 */
	public Message(String msg) {
		// TODO: YOUR CODE HERE
	}
	
	/**
	 * Updates the sketch according to the message
	 * This may result in a modification of the message to be passed on
	 */
	public void update(Sketch sketch) {
		// TODO: YOUR CODE HERE
	}

	/**
	 * Converts to a string representation for communication
	 */
	public String toString() {
		// TODO: YOUR CODE HERE
	}
}
