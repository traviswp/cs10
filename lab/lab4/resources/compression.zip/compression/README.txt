Provided Code for Lab 4: Huffman Coding
=======================================

BinaryTree.java

	The same code as seen in class but with accessor methods added.
	
BufferedBitReader.java & BufferedBitWriter.java

	Convenience classes provided to handle reading/writing bits. 
	Make sure you understand the methods that are provided (the usage should 
	be fairly straight forward.
